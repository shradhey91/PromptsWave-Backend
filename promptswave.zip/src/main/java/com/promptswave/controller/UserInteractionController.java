package com.promptswave.controller;

public class UserInteractionController {

}
