package com.promptswave.controller;

public class PublicCategoryController {

}
