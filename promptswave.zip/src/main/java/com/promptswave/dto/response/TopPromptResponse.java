package com.promptswave.dto.response;

public record TopPromptResponse() {

}
