package com.promptswave.dto.response;

public record PromptResponse() {

}
