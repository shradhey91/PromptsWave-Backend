package com.promptswave.entity;

public class PromptAiEntity {

}
